#!/bin/bash
gnome-session-quit --reboot
