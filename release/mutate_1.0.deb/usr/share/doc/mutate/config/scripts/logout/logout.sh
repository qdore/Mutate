#!/bin/bash
gnome-session-quit --logout
